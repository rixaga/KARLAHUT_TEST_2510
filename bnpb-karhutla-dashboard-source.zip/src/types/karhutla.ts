export type TimeRangeFilter = 'HARI_INI' | '7_HARI_TERAKHIR' | 'PRAKIRAAN_10_HARI';

export type WorkingProvince = 
  | 'SEMUA'
  | 'Riau'
  | 'Jambi'
  | 'Sumatera Selatan'
  | 'Kalimantan Barat'
  | 'Kalimantan Tengah'
  | 'Kalimantan Selatan';

export type HotspotSource = 'NASA_FIRMS' | 'SIPONGI_KLHK' | 'SIMULASI_TERVERIFIKASI';

export type HotspotConfidence = 'nominal' | 'high' | 'low';

export type ValidationStatus = 
  | 'OBSERVASI_SATELIT' 
  | 'VERIFIKASI_GROUNDCHECK_BPBD' 
  | 'TERKONFIRMASI_PEMADAM';

export interface Hotspot {
  id: string;
  source: HotspotSource;
  latitude: number;
  longitude: number;
  brightness: number; // Kelvin
  acq_date: string; // YYYY-MM-DD
  acq_time: string; // HH:MM or HHMM
  satellite: string; // VIIRS-SNPP, NOAA-20, MODIS-Aqua, MODIS-Terra
  confidence: HotspotConfidence;
  frp: number; // MW
  daynight: 'D' | 'N';
  province: string;
  regency: string;
  district?: string;
  village?: string;
  validationStatus: ValidationStatus;
  isForecast?: boolean; // Hotspot besok tidak boleh observasi
}

export type RiskClass = 'TINGGI' | 'SEDANG' | 'RENDAH';

export interface IRBIRecord {
  rank: number;
  province: string;
  regency: string;
  hazardScore: number; // 0-100
  vulnerabilityScore: number; // 0-100
  capacityScore: number; // 0-100
  riskIndex: number; // Skor IRBI Karhutla 2025 (skala 0-250)
  riskClass: RiskClass;
  peatlandAreaHa: number; // Ha
  isPriority20: boolean;
}

export type FDRSClass = 'AMAN' | 'SEDANG' | 'TINGGI' | 'EKSTREM';

export interface BMKGFDRSRecord {
  province: string;
  regency: string;
  date: string;
  ffmc: number; // Fine Fuel Moisture Code
  ffmcClass: FDRSClass;
  fwi: number; // Fire Weather Index
  fwiClass: FDRSClass;
  isi: number; // Initial Spread Index
  isiClass: FDRSClass;
  rainProbability: number; // %
  windSpeedKmH: number;
  windDirection: string;
  smokeHazeRisk: 'NIHIL' | 'RINGAN' | 'SEDANG' | 'PEKAT';
  isForecast: boolean;
  forecastDay: number; // 0: Hari ini, 1-10: Prakiraan
  dataSource: 'BMKG_OFFICIAL' | 'OPEN_METEO_PROTOTYPE';
}

export type ISPUCategory = 'BAIK' | 'SEDANG' | 'TIDAK_SEHAT' | 'SANGAT_TIDAK_SEHAT' | 'BERBAHAYA';

export interface ISPUSiteRecord {
  stationId: string;
  stationName: string;
  province: string;
  city: string;
  timestamp: string;
  pm25: number;
  pm10: number;
  co: number;
  so2: number;
  no2: number;
  o3: number;
  maxParam: string;
  ispuValue: number;
  category: ISPUCategory;
  source: 'KLHK_DITJEN_PPKL';
}

export interface PusdatinEventRecord {
  eventId: string;
  date: string;
  province: string;
  regency: string;
  burnedAreaHa: number;
  personnelCount: number;
  waterBombingSorties: number;
  status: 'TERPADAMKAN' | 'PROSES_PEMADAMAN' | 'PENDINGINAN';
  remarks: string;
}

export interface InaRiskLayerConfig {
  id: string;
  name: string;
  type: 'Bahaya' | 'Risiko' | 'Kapasitas';
  serviceUrl: string;
  opacity: number;
  visible: boolean;
  source: string;
  status: 'ONLINE' | 'SIMULASI_LOKAL' | 'DEGRADED';
  description: string;
  lastUpdated: string;
}

export interface SourceMetadata {
  name: string;
  agency: string;
  period: string;
  timestamp: string;
  validationStatus: string;
  connectionStatus: 'TERHUBUNG' | 'KUNCI_API_BELUM_TERSEDIA' | 'BERKAS_TERIMPOR' | 'ARSIP_VALID';
  details?: string;
}
