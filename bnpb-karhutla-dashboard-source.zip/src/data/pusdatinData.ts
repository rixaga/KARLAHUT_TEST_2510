import type { PusdatinEventRecord } from '../types/karhutla.ts';

/**
 * Catatan Historis Kejadian Karhutla dan Operasi Penanganan Darurat
 * Sumber: Pusat Data, Informasi, dan Komunikasi Kebencanaan (Pusdatin) BNPB
 */
export const PUSDATIN_INCIDENT_RECORDS: PusdatinEventRecord[] = [
  {
    eventId: 'BNPB-KHT-2026-081',
    date: '2026-10-16',
    province: 'Sumatera Selatan',
    regency: 'Kab. Ogan Komering Ilir',
    burnedAreaHa: 42.5,
    personnelCount: 145,
    waterBombingSorties: 38,
    status: 'PROSES_PEMADAMAN',
    remarks: 'Kebakaran lahan gambut kedalaman 1.5 meter di Kec. Pangkalan Lampam. Satgas Darat Gabungan TNI/Polri, BPBD, Manggala Agni dan 2 heli water bombing BNPB dikerahkan.'
  },
  {
    eventId: 'BNPB-KHT-2026-079',
    date: '2026-10-15',
    province: 'Riau',
    regency: 'Kab. Pelalawan',
    burnedAreaHa: 28.0,
    personnelCount: 110,
    waterBombingSorties: 24,
    status: 'PENDINGINAN',
    remarks: 'Pemadaman kepala api berhasil di Desa Kuala Panduk, Kec. Teluk Meranti. Tim satgas darat melanjutkan pembasahan dan penyekatan parit gambut.'
  },
  {
    eventId: 'BNPB-KHT-2026-076',
    date: '2026-10-14',
    province: 'Kalimantan Tengah',
    regency: 'Kab. Kotawaringin Timur',
    burnedAreaHa: 35.2,
    personnelCount: 95,
    waterBombingSorties: 18,
    status: 'PROSES_PEMADAMAN',
    remarks: 'Titik api semak belukar dan gambut dangkal di Mentawa Baru Ketapang. Pemadaman didukung mesin pompa portable dan water bombing heli BNPB tipe Kamov.'
  },
  {
    eventId: 'BNPB-KHT-2026-073',
    date: '2026-10-12',
    province: 'Riau',
    regency: 'Kota Dumai',
    burnedAreaHa: 12.0,
    personnelCount: 65,
    waterBombingSorties: 0,
    status: 'TERPADAMKAN',
    remarks: 'Pemadaman tuntas di Kec. Medang Kampai oleh BPBD Dumai bersama MPA dan regu pemadam Manggala Agni Daops Dumai.'
  },
  {
    eventId: 'BNPB-KHT-2026-070',
    date: '2026-10-10',
    province: 'Kalimantan Barat',
    regency: 'Kab. Ketapang',
    burnedAreaHa: 18.5,
    personnelCount: 75,
    waterBombingSorties: 12,
    status: 'TERPADAMKAN',
    remarks: 'Area gambut terbakar di Kendawangan telah padam berkat hujan lokal dan intervensi satgas darat gabungan.'
  }
];
