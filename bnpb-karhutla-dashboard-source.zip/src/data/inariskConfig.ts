import type { InaRiskLayerConfig } from '../types/karhutla.ts';

/**
 * Konfigurasi Endpoint Resmi ArcGIS REST InaRISK & Geoportal BNPB
 * Sumber: Direktorat Pemetaan dan Evaluasi Risiko Bencana (Dit. PERB) BNPB
 * GIS Portal: https://gis.bnpb.go.id/arcgis/rest/services
 */
export const INARISK_LAYERS: InaRiskLayerConfig[] = [
  {
    id: 'inarisk-bahaya-karhutla',
    name: 'InaRISK: Peta Bahaya Karhutla 2024-2025',
    type: 'Bahaya',
    serviceUrl: 'https://gis.bnpb.go.id/arcgis/rest/services/inaRISK/Bahaya_Karhutla_2024/ImageServer',
    opacity: 0.65,
    visible: true,
    source: 'Dit. Pemetaan dan Evaluasi Risiko Bencana BNPB (InaRISK)',
    status: 'ONLINE',
    description: 'Peta zonasi tingkat bahaya kebakaran hutan dan lahan berdasarkan riwayat hotspot, jenis tutupan lahan, jenis tanah gambut, dan iklim.',
    lastUpdated: 'Oktober 2024 (Revisi Mutakhir)'
  },
  {
    id: 'inarisk-risiko-karhutla',
    name: 'InaRISK: Peta Risiko Karhutla 2024-2025',
    type: 'Risiko',
    serviceUrl: 'https://gis.bnpb.go.id/arcgis/rest/services/inaRISK/Risiko_Karhutla_2024/ImageServer',
    opacity: 0.60,
    visible: false,
    source: 'Dit. Pemetaan dan Evaluasi Risiko Bencana BNPB (InaRISK)',
    status: 'ONLINE',
    description: 'Peta indeks risiko karhutla yang mengintegrasikan komponen bahaya, kerentanan (ekonomi, sosial, ekologi gambut), dan kapasitas daerah.',
    lastUpdated: 'Oktober 2024'
  },
  {
    id: 'bnpb-batas-administrasi',
    name: 'Batas Administrasi Provinsi & Kabupaten/Kota BNPB',
    type: 'Kapasitas',
    serviceUrl: 'https://gis.bnpb.go.id/arcgis/rest/services/Batas_Administrasi/MapServer',
    opacity: 0.85,
    visible: true,
    source: 'Badan Informasi Geospasial (BIG) & Pusat Data BNPB',
    status: 'ONLINE',
    description: 'Batas wilayah resmi 38 provinsi dan 514 kabupaten/kota seluruh Indonesia untuk agregasi spasial hotspot.',
    lastUpdated: '2024 Semester 2'
  }
];
