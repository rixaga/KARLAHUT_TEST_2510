import React, { useState } from 'react';
import { Settings2, X, Key, CheckCircle2, AlertTriangle, ExternalLink, RefreshCw } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  systemStatus: any;
  onRefreshStatus: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  systemStatus,
  onRefreshStatus
}) => {
  const [mapKeyInput, setMapKeyInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const handleSaveMapKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapKeyInput.trim()) return;

    setIsSubmitting(true);
    setFeedbackMsg(null);

    try {
      const res = await fetch('/api/firms/set-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mapKey: mapKeyInput.trim() })
      });
      const data = await res.json();
      if (res.ok) {
        setFeedbackMsg({ text: 'Kunci NASA FIRMS MAP_KEY berhasil disimpan di backend.' });
        onRefreshStatus();
      } else {
        setFeedbackMsg({ text: data.error || 'Gagal menyimpan kunci', isError: true });
      }
    } catch (err: any) {
      setFeedbackMsg({ text: err.message || 'Terjadi kesalahan jaringan', isError: true });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-xl w-full flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-100">
              Konfigurasi Kunci API & Status Koneksi Sistem
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 text-xs text-slate-300">
          {/* Section 1: NASA FIRMS API MAP_KEY */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Key className="w-4 h-4 text-amber-400" />
                NASA FIRMS Area API Map Key
              </span>
              <a
                href="https://firms.modaps.eosdis.nasa.gov/api/map_key/"
                target="_blank"
                rel="noreferrer"
                className="text-amber-400 hover:text-amber-300 flex items-center gap-1 text-[11px]"
              >
                <span>Dapatkan Kunci Gratis</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              Kunci MAP_KEY disimpan dengan aman di backend server (tidak terekspos di browser client) dan digunakan untuk mengunduh titik hotspot berkoordinat riwayat 7 hari.
            </p>

            <form onSubmit={handleSaveMapKey} className="flex gap-2">
              <input
                type="text"
                placeholder="Masukkan 32-karakter NASA FIRMS Map Key..."
                value={mapKeyInput}
                onChange={(e) => setMapKeyInput(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-amber-500"
              />
              <button
                type="submit"
                disabled={isSubmitting || !mapKeyInput.trim()}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isSubmitting ? 'Menyimpan...' : 'Simpan Kunci'}
              </button>
            </form>

            {feedbackMsg && (
              <div
                className={`p-2.5 rounded text-[11px] border ${
                  feedbackMsg.isError
                    ? 'bg-red-950/60 border-red-800 text-red-300'
                    : 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                }`}
              >
                {feedbackMsg.text}
              </div>
            )}
          </div>

          {/* Section 2: Matriks Status Koneksi 7 Integrasi Utama */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200">
                Matriks Diagnostik 7 Sumber Data Terpadu:
              </span>
              <button
                onClick={onRefreshStatus}
                className="text-slate-400 hover:text-slate-200 flex items-center gap-1 text-[11px]"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Segarkan Status</span>
              </button>
            </div>

            <div className="space-y-2 font-mono text-[11px]">
              {/* NASA FIRMS */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">1. NASA FIRMS Area API</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    {systemStatus?.firms?.message || 'Memeriksa koneksi...'}
                  </div>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-semibold ${
                  systemStatus?.firms?.keyConfigured ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-400'
                }`}>
                  {systemStatus?.firms?.keyConfigured ? 'LIVE API' : 'DATASET VALID'}
                </span>
              </div>

              {/* SiPongi */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">2. KLHK SiPongi+ (Ditjen PPI)</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    {systemStatus?.sipongi?.fileName || 'sipongi_resmi.csv'} · {systemStatus?.sipongi?.importedCount || 0} Titik Terimpor
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  BERKAS RESMI AKTIF
                </span>
              </div>

              {/* InaRISK */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">3. InaRISK ArcGIS REST ImageServer</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    https://gis.bnpb.go.id/arcgis/rest/services/inaRISK
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  TERHUBUNG
                </span>
              </div>

              {/* Batas Wilayah */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">4. Batas Administrasi BIG / BNPB</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    Geoportal BNPB · 38 Provinsi & 514 Kab/Kota
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  TERHUBUNG
                </span>
              </div>

              {/* IRBI 2025 */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">5. IRBI Karhutla 2025 (Dit. PERB)</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    Indeks Risiko Bencana Indonesia Edisi 2025
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  DATABASE VALID
                </span>
              </div>

              {/* BMKG FDRS */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">6. BMKG FDRS (FFMC/FWI/ISI)</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    Model Numerik Cuaca & Buletin Karhutla BMKG
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  TERHUBUNG
                </span>
              </div>

              {/* ISPU & Pusdatin */}
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-sans font-medium text-slate-200">7. ISPU KLH & Pusdatin BNPB</div>
                  <div className="text-slate-500 text-[10px] font-sans">
                    Sensor Ambien AQMS & Catatan Operasi Darurat
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  TERHUBUNG
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium transition-colors text-xs"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
