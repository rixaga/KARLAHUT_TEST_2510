import React, { useState } from 'react';
import { Upload, X, FileText, CheckCircle2, AlertCircle, Info } from 'lucide-react';
import * as XLSX from 'xlsx';
import type { Hotspot } from '../types/karhutla.ts';

interface FileImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportSuccess: (hotspots: Hotspot[], message: string) => void;
}

export const FileImportModal: React.FC<FileImportModalProps> = ({
  isOpen,
  onClose,
  onImportSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'SIPONGI' | 'BMKG' | 'ISPU'>('SIPONGI');
  const [fileName, setFileName] = useState('');
  const [fileContent, setFileContent] = useState('');
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg('');
    setFileName(file.name);
    setIsProcessing(true);

    try {
      const ext = file.name.split('.').pop()?.toLowerCase();

      if (ext === 'xlsx' || ext === 'xls') {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        // Convert to CSV string for uniform backend parsing
        const csvText = XLSX.utils.sheet_to_csv(worksheet);
        setFileContent(csvText);

        const jsonRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        setPreviewRows(jsonRows.slice(0, 5));
      } else {
        // CSV, TXT, KML
        const text = await file.text();
        setFileContent(text);
        const lines = text.split('\n').filter(l => l.trim().length > 0);
        setPreviewRows(lines.slice(0, 5).map(l => l.split(',')));
      }
    } catch (err: any) {
      setErrorMsg(`Gagal membaca berkas: ${err.message || 'Format tidak didukung'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLoadSample = () => {
    const sample = `Tanggal,Waktu,Satelit,Lintang,Bujur,Tingkat_Kepercayaan,Provinsi,Kabupaten,Kecamatan,Desa,FRP
2026-10-17,14:10,VIIRS-SNPP,0.342,102.185,Tinggi,Riau,Kab. Pelalawan,Teluk Meranti,Kuala Panduk,42.5
2026-10-17,14:22,NOAA-20,-3.450,105.195,Tinggi,Sumatera Selatan,Kab. Ogan Komering Ilir,Pangkalan Lampam,Rambai,51.0
2026-10-17,13:55,VIIRS-SNPP,-2.115,112.810,Sedang,Kalimantan Tengah,Kab. Kotawaringin Timur,Mentawa Baru Ketapang,Bapeang,28.4
2026-10-17,14:05,MODIS-Aqua,-1.840,109.970,Sedang,Kalimantan Barat,Kab. Ketapang,Kendawangan,Sungai Gantang,22.1
2026-10-17,14:30,VIIRS-SNPP,1.485,102.130,Tinggi,Riau,Kab. Bengkalis,Bukit Batu,Pakning Asal,33.0`;

    setFileName('contoh_ekspor_resmi_sipongi_klhk.csv');
    setFileContent(sample);
    setPreviewRows([
      ['Tanggal', 'Waktu', 'Satelit', 'Lintang', 'Bujur', 'Tingkat_Kepercayaan', 'Provinsi', 'Kabupaten', 'FRP'],
      ['2026-10-17', '14:10', 'VIIRS-SNPP', '0.342', '102.185', 'Tinggi', 'Riau', 'Kab. Pelalawan', '42.5'],
      ['2026-10-17', '14:22', 'NOAA-20', '-3.450', '105.195', 'Tinggi', 'Sumatera Selatan', 'Kab. Ogan Komering Ilir', '51.0'],
      ['2026-10-17', '13:55', 'VIIRS-SNPP', '-2.115', '112.810', 'Sedang', 'Kalimantan Tengah', 'Kab. Kotawaringin Timur', '28.4']
    ]);
  };

  const handleProcessImport = async () => {
    if (!fileContent) {
      setErrorMsg('Pilih berkas terlebih dahulu.');
      return;
    }

    setIsProcessing(true);
    setErrorMsg('');

    try {
      const response = await fetch('/api/sipongi/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: fileContent, fileName })
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || 'Gagal memproses berkas di server');
      }

      // Re-fetch hotspots from server to update parent
      const hotspotsRes = await fetch('/api/firms/hotspots');
      const hotspotsJson = await hotspotsRes.json();

      onImportSuccess(hotspotsJson.data, result.message);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Terjadi kesalahan saat mengimpor.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-xl w-full flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-100">
              Impor Berkas Resmi SiPongi+ & BMKG
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 text-xs">
          {/* Format Explanation Notice */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded flex gap-2.5 text-slate-300">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-200 mb-0.5">
                Protokol Integrasi Berkas Resmi Dit. PD BNPB:
              </p>
              <p className="leading-relaxed text-slate-400">
                Sistem KLHK SiPongi+ tidak menyediakan public REST API; pembaruan data dilakukan melalui impor berkas ekspor tabular resmi (XLSX, CSV, TXT) atau KMZ spasial.
              </p>
            </div>
          </div>

          {/* Tab Selector */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded border border-slate-800">
            <button
              onClick={() => setActiveTab('SIPONGI')}
              className={`flex-1 py-1.5 rounded font-medium transition-colors ${
                activeTab === 'SIPONGI' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              SiPongi+ KLHK (Hotspot)
            </button>
            <button
              onClick={() => setActiveTab('BMKG')}
              className={`flex-1 py-1.5 rounded font-medium transition-colors ${
                activeTab === 'BMKG' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Buletin BMKG (FDRS)
            </button>
            <button
              onClick={() => setActiveTab('ISPU')}
              className={`flex-1 py-1.5 rounded font-medium transition-colors ${
                activeTab === 'ISPU' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ISPU / Pusdatin
            </button>
          </div>

          {/* File Upload Area */}
          <div className="border-2 border-dashed border-slate-700 hover:border-amber-500/60 rounded-lg p-6 text-center transition-colors bg-slate-950/40">
            <input
              type="file"
              id="file-upload"
              accept=".xlsx,.xls,.csv,.txt,.kmz,.kml"
              onChange={handleFileUpload}
              className="hidden"
            />
            <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center justify-center">
              <FileText className="w-8 h-8 text-slate-400 mb-2" />
              <span className="font-medium text-slate-200">
                {fileName ? fileName : 'Klik untuk memilih berkas atau seret ke sini'}
              </span>
              <span className="text-[11px] text-slate-400 mt-1">
                Mendukung XLSX, XLS, CSV, TXT, KMZ (Maksimal 20MB)
              </span>
            </label>
          </div>

          {/* Quick Demo Sample Loader */}
          <div className="flex items-center justify-between pt-1">
            <button
              onClick={handleLoadSample}
              type="button"
              className="text-amber-400 hover:text-amber-300 font-medium underline text-[11px]"
            >
              + Muat Berkas Sampel Resmi SiPongi (5 Titik Api)
            </button>
            {fileName && (
              <span className="text-emerald-400 flex items-center gap-1 font-mono text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5" /> Berkas Siap Diunggah
              </span>
            )}
          </div>

          {/* Preview Table if rows exist */}
          {previewRows.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[11px] text-slate-400 font-semibold">Pratinjau Data:</span>
              <div className="max-h-28 overflow-auto border border-slate-800 rounded bg-slate-950 text-[11px] font-mono">
                <table className="w-full text-left">
                  <tbody>
                    {previewRows.map((row, i) => (
                      <tr key={i} className={i === 0 ? 'bg-slate-900 font-bold text-slate-300' : 'border-t border-slate-900 text-slate-400'}>
                        {Array.isArray(row) && row.slice(0, 6).map((cell, j) => (
                          <td key={j} className="p-1 px-2 whitespace-nowrap">{String(cell)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-2.5 bg-red-950/60 border border-red-800 text-red-300 rounded flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 rounded transition-colors"
          >
            Batal
          </button>
          <button
            onClick={handleProcessImport}
            disabled={!fileContent || isProcessing}
            className={`px-4 py-2 text-xs font-semibold text-white rounded transition-colors ${
              fileContent && !isProcessing
                ? 'bg-amber-600 hover:bg-amber-500'
                : 'bg-slate-700 cursor-not-allowed opacity-60'
            }`}
          >
            {isProcessing ? 'Memproses Berkas...' : 'Mulai Impor & Validasi'}
          </button>
        </div>
      </div>
    </div>
  );
};
