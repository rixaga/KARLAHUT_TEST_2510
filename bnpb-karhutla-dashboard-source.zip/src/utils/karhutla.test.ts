import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyFFMC, classifyFWI, classifyISI, getFDRSColor } from './fdrsCalc.ts';
import { classifyISPU, getISPUColor } from './ispuRating.ts';
import { parseSiPongiCSV } from './sipongiParser.ts';
import { calculateDistanceKm, findNearestPriorityRegency, PRIORITY_20_REGENCIES } from './geo.ts';

test('FDRS BMKG classifications match official thresholds', () => {
  // FFMC
  assert.equal(classifyFFMC(55), 'AMAN');
  assert.equal(classifyFFMC(70), 'SEDANG');
  assert.equal(classifyFFMC(80), 'TINGGI');
  assert.equal(classifyFFMC(92), 'EKSTREM');

  // FWI
  assert.equal(classifyFWI(5), 'AMAN');
  assert.equal(classifyFWI(10), 'SEDANG');
  assert.equal(classifyFWI(18), 'TINGGI');
  assert.equal(classifyFWI(28), 'EKSTREM');

  // ISI
  assert.equal(classifyISI(1.5), 'AMAN');
  assert.equal(classifyISI(4.5), 'SEDANG');
  assert.equal(classifyISI(8.5), 'TINGGI');
  assert.equal(classifyISI(15.0), 'EKSTREM');

  // Color check
  assert.equal(getFDRSColor('EKSTREM'), '#dc2626');
});

test('KLHK ISPU ratings follow Permen LHK 14/2020', () => {
  assert.equal(classifyISPU(35), 'BAIK');
  assert.equal(classifyISPU(75), 'SEDANG');
  assert.equal(classifyISPU(145), 'TIDAK_SEHAT');
  assert.equal(classifyISPU(250), 'SANGAT_TIDAK_SEHAT');
  assert.equal(classifyISPU(350), 'BERBAHAYA');

  assert.equal(getISPUColor('BAIK'), '#16a34a');
  assert.equal(getISPUColor('BERBAHAYA'), '#701a75');
});

test('SiPongi CSV Parser handles standard KLHK export format', () => {
  const sampleCsv = `Tanggal,Waktu,Satelit,Lintang,Bujur,Tingkat_Kepercayaan,Provinsi,Kabupaten,FRP
2026-10-16,13:30,VIIRS-SNPP,0.285,102.140,Tinggi,Riau,Kab. Pelalawan,24.8
2026-10-16,14:15,NOAA-20,-3.380,105.120,Sedang,Sumatera Selatan,Kab. Ogan Komering Ilir,18.2
2026-10-16,15:00,MODIS-Aqua,-2.080,112.740,85,Kalimantan Tengah,Kab. Kotawaringin Timur,32.0`;

  const parsed = parseSiPongiCSV(sampleCsv);
  assert.equal(parsed.length, 3);
  assert.equal(parsed[0].regency, 'Kab. Pelalawan');
  assert.equal(parsed[0].confidence, 'high');
  assert.equal(parsed[0].province, 'Riau');
  assert.equal(parsed[1].province, 'Sumatera Selatan');
  assert.equal(parsed[2].confidence, 'high');
});

test('Spatial calculation and nearest priority regency match', () => {
  // Coordinates very close to Pelalawan (0.2833, 102.1333)
  const nearby = findNearestPriorityRegency(0.29, 102.14);
  assert.ok(nearby);
  assert.equal(nearby.regency.name, 'Kab. Pelalawan');
  assert.ok(nearby.distanceKm < 15);

  // Exact 20 priority regencies defined
  assert.equal(PRIORITY_20_REGENCIES.length, 20);

  // Distance formula check (same point = 0)
  assert.equal(calculateDistanceKm(0, 0, 0, 0), 0);
});
