import type { Hotspot, HotspotConfidence } from '../types/karhutla.ts';

export function detectDelimeter(text: string): string {
  const firstLine = text.split('\n')[0] || '';
  if (firstLine.includes('\t')) return '\t';
  if (firstLine.includes(';')) return ';';
  return ',';
}

export function parseSiPongiCSV(csvText: string, fileName = 'sipongi_export.csv'): Hotspot[] {
  if (!csvText || !csvText.trim()) return [];

  const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
  if (lines.length < 2) return [];

  const delim = detectDelimeter(lines[0]);
  const headers = lines[0].split(delim).map(h => h.trim().toLowerCase().replace(/["']/g, ''));

  // Find column indices
  const latIdx = headers.findIndex(h => h.includes('lat') || h.includes('lintang') || h === 'y');
  const lonIdx = headers.findIndex(h => h.includes('lon') || h.includes('bujur') || h === 'x');
  const dateIdx = headers.findIndex(h => h.includes('date') || h.includes('tanggal') || h.includes('tgl') || h.includes('waktu'));
  const timeIdx = headers.findIndex(h => h.includes('time') || h.includes('jam') || h.includes('pukul'));
  const satIdx = headers.findIndex(h => h.includes('sat') || h.includes('sensor'));
  const confIdx = headers.findIndex(h => h.includes('conf') || h.includes('kepercayaan') || h.includes('tingkat'));
  const provIdx = headers.findIndex(h => h.includes('prov'));
  const kabIdx = headers.findIndex(h => h.includes('kab') || h.includes('kota') || h.includes('regency'));
  const kecIdx = headers.findIndex(h => h.includes('kec'));
  const desaIdx = headers.findIndex(h => h.includes('desa') || h.includes('kel'));
  const frpIdx = headers.findIndex(h => h.includes('frp') || h.includes('power'));
  const brightIdx = headers.findIndex(h => h.includes('bright') || h.includes('suhu') || h.includes('temp'));

  if (latIdx === -1 || lonIdx === -1) {
    throw new Error('Kolom koordinat Latitude/Lintang dan Longitude/Bujur tidak ditemukan dalam berkas SiPongi.');
  }

  const hotspots: Hotspot[] = [];

  for (let i = 1; i < lines.length; i++) {
    const rawCols = lines[i].split(delim).map(c => c.trim().replace(/^["']|["']$/g, ''));
    if (rawCols.length <= Math.max(latIdx, lonIdx)) continue;

    const lat = parseFloat(rawCols[latIdx]);
    const lon = parseFloat(rawCols[lonIdx]);

    if (isNaN(lat) || isNaN(lon)) continue;
    // Indonesia coordinate bounds sanity check: lat -12 to 7, lon 94 to 142
    if (lat < -12 || lat > 7 || lon < 94 || lon > 142) continue;

    const rawConf = confIdx !== -1 && rawCols[confIdx] ? rawCols[confIdx].toLowerCase() : 'nominal';
    let confidence: HotspotConfidence = 'nominal';
    if (rawConf.includes('high') || rawConf.includes('tinggi') || parseInt(rawConf, 10) >= 80) {
      confidence = 'high';
    } else if (rawConf.includes('low') || rawConf.includes('rendah') || (parseInt(rawConf, 10) < 50 && parseInt(rawConf, 10) > 0)) {
      confidence = 'low';
    }

    const acq_date = dateIdx !== -1 && rawCols[dateIdx] ? rawCols[dateIdx] : new Date().toISOString().slice(0, 10);
    const acq_time = timeIdx !== -1 && rawCols[timeIdx] ? rawCols[timeIdx] : '07:00';
    const satellite = satIdx !== -1 && rawCols[satIdx] ? rawCols[satIdx] : 'VIIRS-SNPP (SiPongi+)';
    const province = provIdx !== -1 && rawCols[provIdx] ? rawCols[provIdx] : 'Sumatera / Kalimantan';
    const regency = kabIdx !== -1 && rawCols[kabIdx] ? rawCols[kabIdx] : '-';
    const district = kecIdx !== -1 && rawCols[kecIdx] ? rawCols[kecIdx] : undefined;
    const village = desaIdx !== -1 && rawCols[desaIdx] ? rawCols[desaIdx] : undefined;
    const frp = frpIdx !== -1 && !isNaN(parseFloat(rawCols[frpIdx])) ? parseFloat(rawCols[frpIdx]) : 12.5;
    const brightness = brightIdx !== -1 && !isNaN(parseFloat(rawCols[brightIdx])) ? parseFloat(rawCols[brightIdx]) : 325.4;

    hotspots.push({
      id: `SIPONGI-${i}-${Date.now().toString().slice(-4)}`,
      source: 'SIPONGI_KLHK',
      latitude: lat,
      longitude: lon,
      brightness,
      acq_date,
      acq_time,
      satellite,
      confidence,
      frp,
      daynight: 'D',
      province,
      regency,
      district,
      village,
      validationStatus: 'OBSERVASI_SATELIT'
    });
  }

  return hotspots;
}
